
-- -----------------------------------------------------
-- Table `ac_controller_DEVICE`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS ac_controller_DEVICE (
  ac_controller_DEVICE_ID VARCHAR(45) NOT NULL ,
  DEVICE_NAME VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (ac_controller_DEVICE_ID) );

